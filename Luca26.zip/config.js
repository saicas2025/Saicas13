// Sostituisci con l'URL del tuo backend (Replit/Vercel/Netlify Function).
// Esempio: https://preventivo-ai.youruser.repl.co oppure https://tuo-dominio.netlify.app/.netlify/functions/ai
window.APP_CONFIG = {
  BACKEND_URL: "https://INSERISCI-QUI-IL-TUO-BACKEND" // <-- CAMBIA QUESTA RIGA
};
